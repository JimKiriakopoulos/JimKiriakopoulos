package dxr;

import javax.swing.*;
import java.awt.*;

public class MainWindow extends JFrame {
    public MainWindow() {
    	getContentPane().setBackground(new Color(128, 255, 255));
        setTitle("Πληροφορίες Έκδοσης");
        setSize(300, 150);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // 💠 Εικονίδιο παραθύρου
        try {
            // Δώσε τη σωστή διαδρομή εικόνας εδώ
            setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindow.class.getResource("/dxr/27cca85d3e344998abc624b5978faec3.png")));
        } catch (Exception ex) {
            System.err.println("⚠ Δεν φορτώθηκε το εικονίδιο παραθύρου: " + ex.getMessage());
        }

        JLabel versionLabel = new JLabel(
            "<html><center>Έκδοση 1.0<br/>© 2025 Jim Kiriakopoulos</center></html>",
            SwingConstants.CENTER
        );
        versionLabel.setBackground(new Color(128, 255, 255));
        versionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        getContentPane().add(versionLabel, BorderLayout.CENTER);

        setVisible(true);  // να φαίνεται στο χρήστη
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow());
    }
}
