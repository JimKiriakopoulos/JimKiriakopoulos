package dxr;

import java.sql.Connection;

public class TestMain {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.connect()) {
            if (conn != null) {
                System.out.println("🎉 Η σύνδεση έγινε με επιτυχία!");
            } else {
                System.out.println("❌ Η σύνδεση απέτυχε.");
            }
        } catch (Exception e) {
            System.out.println("⚠ Σφάλμα κατά τη σύνδεση: " + e.getMessage());
        }
    }
}
