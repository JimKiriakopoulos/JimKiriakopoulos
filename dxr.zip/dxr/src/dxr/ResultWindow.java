package dxr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResultWindow extends JFrame {
    private JTextField idField, fnameField, lnameField;
    private JFrame parent;
    private int currentIndex = 0;
    private List<Integer> ids = new ArrayList<>();
    private String searchQuery;

    public ResultWindow(JFrame parent, String lnameSearch) {
        super("Αποτελέσματα Αναζήτησης");
        this.parent = parent;
        this.searchQuery = lnameSearch;

        setSize(700, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        try {
            setIconImage(new ImageIcon(getClass().getResource("/dxr/27cca85d3e344998abc624b5978faec3.png")).getImage());
        } catch (Exception ignored) {}

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (parent != null) parent.setEnabled(true);
            }
        });

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(102, 178, 255), 0, getHeight(), Color.WHITE);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblId = new JLabel("ID:");
        JLabel lblFname = new JLabel("Όνομα:");
        JLabel lblLname = new JLabel("Επώνυμο:");

        idField = new JTextField(10); idField.setEditable(false);
        fnameField = new JTextField(15);
        lnameField = new JTextField(15);

        JButton prevButton = new JButton("Προηγούμενο");
        JButton nextButton = new JButton("Επόμενο");
        JButton updateButton = new JButton("Ενημέρωση");
        JButton deleteButton = new JButton("Διαγραφή");

        for (JButton btn : new JButton[]{prevButton, nextButton, updateButton, deleteButton}) {
            btn.setBackground(new Color(0, 120, 215));
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        }

        loadIds();

        if (ids.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Δεν βρέθηκαν εγγραφές.");
            dispose();
            return;
        }

        showCurrent();

        prevButton.addActionListener(e -> {
            if (!ids.isEmpty()) {
                currentIndex = (currentIndex > 0) ? currentIndex - 1 : ids.size() - 1;
                System.out.println("Current index: " + currentIndex); // 🔍 Εκτύπωσε το index για debugging
                showCurrent();
            }
        });

        nextButton.addActionListener(e -> {
            if (!ids.isEmpty()) {
                currentIndex = (currentIndex < ids.size() - 1) ? currentIndex + 1 : 0;
                System.out.println("Current index: " + currentIndex); // 🔍 Δες αν αλλάζει σωστά
                showCurrent();
            }
        });


        updateButton.addActionListener(e -> {
            try (Connection conn2 = DBConnection.connect()) {
                PreparedStatement stmt2 = conn2.prepareStatement(
                    "UPDATE persons SET PERSON_FNAME = ?, PERSON_LNAME = ? WHERE PERSON_ID = ?"
                );
                stmt2.setString(1, fnameField.getText());
                stmt2.setString(2, lnameField.getText());
                stmt2.setInt(3, ids.get(currentIndex));
                stmt2.executeUpdate();
                JOptionPane.showMessageDialog(this, "Ενημερώθηκε επιτυχώς.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Σφάλμα: " + ex.getMessage());
            }
        });

        deleteButton.addActionListener(e -> {
            try (Connection conn2 = DBConnection.connect()) {
                PreparedStatement stmt2 = conn2.prepareStatement("DELETE FROM persons WHERE PERSON_ID = ?");
                stmt2.setInt(1, ids.get(currentIndex));
                stmt2.executeUpdate();
                ids.remove(currentIndex);
                if (ids.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Δεν υπάρχουν άλλες εγγραφές.");
                    dispose();
                    return;
                }
                if (currentIndex >= ids.size()) currentIndex = 0;
                loadIds();
                showCurrent();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Σφάλμα: " + ex.getMessage());
            }
        });

        GroupLayout gl = new GroupLayout(panel);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addGroup(gl.createSequentialGroup()
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(lblId)
                        .addComponent(lblFname)
                        .addComponent(lblLname))
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(idField)
                        .addComponent(fnameField)
                        .addComponent(lnameField)))
                .addGroup(gl.createSequentialGroup()
                    .addComponent(prevButton)
                    .addComponent(nextButton))
                .addGroup(gl.createSequentialGroup()
                    .addComponent(updateButton)
                    .addComponent(deleteButton))
        );

        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblId)
                    .addComponent(idField))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFname)
                    .addComponent(fnameField))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLname)
                    .addComponent(lnameField))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(prevButton)
                    .addComponent(nextButton))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(updateButton)
                    .addComponent(deleteButton))
        );

        panel.setLayout(gl);
        setContentPane(panel);
    }

    private void loadIds() {
        ids.clear();
        try (Connection conn2 = DBConnection.connect()) {
            PreparedStatement stmt2 = conn2.prepareStatement("SELECT PERSON_ID FROM persons");
            ResultSet rs = stmt2.executeQuery();

            while (rs.next()) {
                ids.add(rs.getInt("PERSON_ID"));
            }

            System.out.println("Loaded IDs: " + ids); // 🔍 Δες αν η λίστα γεμίζει σωστά!

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Σφάλμα φόρτωσης IDs: " + ex.getMessage());
        }
    }

    private void showCurrent() {
        try (Connection conn = DBConnection.connect()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM persons WHERE PERSON_ID = ?");
            stmt.setInt(1, ids.get(currentIndex));
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                idField.setText(String.valueOf(rs.getInt("PERSON_ID")));
                fnameField.setText(rs.getString("PERSON_FNAME"));
                lnameField.setText(rs.getString("PERSON_LNAME"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Σφάλμα εμφάνισης εγγραφής: " + ex.getMessage());
        }
    }
}
