package dxr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SearchInsertWindow extends JFrame {
    private JTextField lnameField;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SearchInsertWindow().setVisible(true));
    }

    public SearchInsertWindow() {
        super("Αναζήτηση / Εισαγωγή");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        try {
            setIconImage(Toolkit.getDefaultToolkit().getImage(SearchInsertWindow.class.getResource("/dxr/27cca85d3e344998abc624b5978faec3.png")));
        } catch (Exception e) {
            System.err.println("⚠ Δεν φορτώθηκε το εικονίδιο: " + e.getMessage());
        }

        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(128, 255, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints gbcLabel = new GridBagConstraints();
        gbcLabel.insets = new Insets(5, 5, 5, 5);
        gbcLabel.gridx = 0;
        gbcLabel.gridy = 0;
        gbcLabel.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Επώνυμο:"), gbcLabel);

        lnameField = new JTextField(20);
        GridBagConstraints gbcField = new GridBagConstraints();
        gbcField.insets = new Insets(5, 5, 5, 5);
        gbcField.gridx = 1;
        gbcField.gridy = 0;
        gbcField.fill = GridBagConstraints.HORIZONTAL;
        gbcField.weightx = 1.0;
        panel.add(lnameField, gbcField);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnPanel.setBackground(new Color(128, 255, 255));
        JButton searchButton = new JButton("Αναζήτηση");
        JButton insertButton = new JButton("Νέα Εγγραφή");
        btnPanel.add(searchButton);
        btnPanel.add(insertButton);

        GridBagConstraints gbcButtons = new GridBagConstraints();
        gbcButtons.insets = new Insets(5, 5, 5, 5);
        gbcButtons.gridx = 0;
        gbcButtons.gridy = 1;
        gbcButtons.gridwidth = 2;
        gbcButtons.anchor = GridBagConstraints.CENTER;
        panel.add(btnPanel, gbcButtons);

        searchButton.addActionListener(e -> onSearch());
        insertButton.addActionListener(e -> onInsert());

        setContentPane(panel);
    }

    private void onSearch() {
        String lname = lnameField.getText().trim();
        if (lname.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Παρακαλώ εισάγετε ένα επώνυμο για αναζήτηση.",
                "Ελλιπή δεδομένα",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        List<Integer> ids = loadPersonIds(lname);
        if (ids.isEmpty()) {
            int choice = JOptionPane.showConfirmDialog(
                this,
                "Δεν βρέθηκαν αποτελέσματα. Θέλετε να εισάγετε νέα εγγραφή;",
                "Καμία εγγραφή",
                JOptionPane.YES_NO_OPTION
            );

            if (choice == JOptionPane.YES_OPTION) {
                this.setEnabled(false);
                InsertWindow insertWin = new InsertWindow(this);
                insertWin.setVisible(true);
            }
            return;
        }

        this.setEnabled(false);
        ResultWindow resultWin = new ResultWindow(this, lname);
        resultWin.setVisible(true);
    }

    private void onInsert() {
        this.setEnabled(false);
        InsertWindow insertWin = new InsertWindow(this);
        insertWin.setVisible(true);
    }

    private List<Integer> loadPersonIds(String lname) {
        List<Integer> ids = new ArrayList<>();
        try (Connection conn = DBConnection.connect()) {
            PreparedStatement stmt = conn.prepareStatement("SELECT PERSON_ID FROM persons WHERE PERSON_LNAME LIKE ?");
            stmt.setString(1, "%" + lname + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                ids.add(rs.getInt("PERSON_ID"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Σφάλμα φόρτωσης δεδομένων: " + ex.getMessage());
        }
        return ids;
    }
}
