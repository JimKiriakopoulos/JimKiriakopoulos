package dxr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    /** Επιστρέφει Connection ή null αν αποτύχει */
    public static Connection connect() {
        // 1) Στοιχεία τοπικού server
        String url      = "jdbc:mysql://localhost:3306/kataxvrisei"
                        + "?useSSL=false&serverTimezone=Europe/Athens";
        String user     = "root";
        String password = "root";

        try {
            // 2) Φόρτωση MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 3) Σύνδεση
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Connection successful to kataxvrisei");
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("❌ Connection failed: " + e.getMessage());
        }
        return null;
    }
}
