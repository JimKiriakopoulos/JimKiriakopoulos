package dxr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
public class axrikoparathiro extends JFrame {

    public axrikoparathiro() {
        setTitle("Αρχικό Παράθυρο");
        setSize(626, 299);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new GridBagLayout());

        // 🎨 Φόντο παραθύρου
        getContentPane().setBackground(new Color(128, 255, 255));

        // 🖼️ Εικονίδιο παραθύρου
        try {
            setIconImage(Toolkit.getDefaultToolkit().getImage(
                "C:\\Users\\dimit\\OneDrive\\Adobe\\27cca85d3e344998abc624b5978faec3.png"
            ));
        } catch (Exception ex) {
            System.err.println("⚠ Δεν φορτώθηκε το εικονίδιο: " + ex.getMessage());
        }

        // 🔘 Κουμπιά
        JButton employeeBtn = new JButton("Εργαζόμενος");
        employeeBtn.addActionListener((ActionEvent e) -> {
            new SearchInsertWindow().setVisible(true);
            dispose();
        });

        JButton versionBtn = new JButton("Έκδοση");
        versionBtn.addActionListener((ActionEvent e) -> {
            new MainWindow().setVisible(true);
            dispose();
        });

        // ✅ Ξεχωριστά GridBagConstraints για κάθε add()
        GridBagConstraints gbc1 = new GridBagConstraints();
        gbc1.insets = new Insets(10, 10, 10, 10);
        gbc1.gridx = 0;
        gbc1.gridy = 0;
        gbc1.fill = GridBagConstraints.HORIZONTAL;
        getContentPane().add(employeeBtn, gbc1);

        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.insets = new Insets(10, 10, 10, 10);
        gbc2.gridx = 0;
        gbc2.gridy = 1;
        gbc2.fill = GridBagConstraints.HORIZONTAL;
        getContentPane().add(versionBtn, gbc2);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new axrikoparathiro().setVisible(true);
        });
    }
}

