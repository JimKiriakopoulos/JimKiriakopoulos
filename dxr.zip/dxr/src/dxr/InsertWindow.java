package dxr;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertWindow extends JFrame {
    private JPanel contentPane;
    private JTextField idField;
    private JTextField fnameField;
    private JTextField lnameField;
    private JButton saveButton;
    private JFrame parent;

    public static void showWithParent(JFrame parent) {
        if (parent != null) parent.setEnabled(false);
        InsertWindow window = new InsertWindow(parent);
        window.setVisible(true);
    }

    public InsertWindow(JFrame parent) {
        this.parent = parent;
        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InsertWindow(null).setVisible(true));
    }

    private void initComponents() {
        setTitle("Εφαρμογή Εργασίας Ατόμων - Νέα Εγγραφή");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // 🖼️ Εικονίδιο παραθύρου
        try {
            setIconImage(new ImageIcon(getClass().getResource("/dxr/27cca85d3e344998abc624b5978faec3.png")).getImage());
        } catch (Exception e) {
            System.err.println(" Δεν φορτώθηκε το εικονίδιο παραθύρου.");
        }

        // 🌈 Gradient φόντο
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(102, 178, 255),
                    0, getHeight(), Color.WHITE
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        contentPane.setBackground(new Color(128, 255, 255));
        contentPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);

        // 🔙 Επανενεργοποίηση parent όταν κλείνει
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (parent != null) parent.setEnabled(true);
            }
        });

        // 📌 Logo
        JLabel lblLogo = new JLabel();
        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        try {
            ImageIcon logoIcon = new ImageIcon(getClass().getResource("/dxr/dentra&sennefa.png"));
            Image img = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            lblLogo.setIcon(new ImageIcon(img));
        } catch (Exception ex) {
            lblLogo.setText("[Logo not found]");
            lblLogo.setForeground(Color.RED.darker());
        }

        // 🔤 Υπότιτλος
        JLabel lblSubtitle = new JLabel("Empowering every person and organization on the planet to achieve more.");
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblSubtitle.setForeground(Color.DARK_GRAY);
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);

        // 🔠 Πεδία
        JLabel lblId = new JLabel("ID:");
        JLabel lblFirstName = new JLabel("Όνομα:");
        JLabel lblLastName = new JLabel("Επώνυμο:");
        idField = new JTextField(15);
        fnameField = new JTextField(15);
        lnameField = new JTextField(15);

        lblId.setForeground(Color.DARK_GRAY);
        lblFirstName.setForeground(Color.DARK_GRAY);
        lblLastName.setForeground(Color.DARK_GRAY);

        // 💾 Κουμπί αποθήκευσης
        saveButton = new JButton("Αποθήκευση");
        saveButton.setBackground(new Color(0, 120, 215));
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(e -> saveRecord());

        // 🔙 Κουμπί επιστροφής
        JButton backButton = new JButton("Επιστροφή");
        backButton.setBackground(new Color(100, 100, 100));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            if (parent != null) parent.setEnabled(true);
            dispose();
        });

        // 📐 Layout
        GroupLayout gl = new GroupLayout(contentPane);
        contentPane.setLayout(gl);
        gl.setAutoCreateGaps(true);
        gl.setAutoCreateContainerGaps(true);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(lblLogo, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                .addComponent(lblSubtitle)
                .addGroup(gl.createSequentialGroup()
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(lblId)
                        .addComponent(lblFirstName)
                        .addComponent(lblLastName))
                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(idField, 340, 340, 340)
                        .addComponent(fnameField, 340, 340, 340)
                        .addComponent(lnameField, 340, 340, 340)))
                .addGroup(gl.createSequentialGroup()
                    .addComponent(backButton)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(saveButton))
        );

        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(lblLogo, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                .addComponent(lblSubtitle)
                .addGap(20)
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblId)
                    .addComponent(idField))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFirstName)
                    .addComponent(fnameField))
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblLastName)
                    .addComponent(lnameField))
                .addGap(20)
                .addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(backButton)
                    .addComponent(saveButton))
        );
    }

    private void saveRecord() {
        String idText = idField.getText().trim();
        String firstName = fnameField.getText().trim();
        String lastName = lnameField.getText().trim();

        if (idText.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Παρακαλώ συμπληρώστε όλα τα πεδία.",
                "Προειδοποίηση", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.connect()) {
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO PERSONS (PERSON_ID, PERSON_FNAME, PERSON_LNAME) VALUES (?, ?, ?)"
            );
            stmt.setInt(1, Integer.parseInt(idText));
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            int count = stmt.executeUpdate();

            if (count > 0) {
                JOptionPane.showMessageDialog(this,
                    "Εγγραφή επιτυχής!", "Επιτυχία", JOptionPane.INFORMATION_MESSAGE);
                idField.setText(""); fnameField.setText(""); lnameField.setText("");
            } else {
                JOptionPane.showMessageDialog(this,
                    "Δεν εισήχθη η εγγραφή.", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this,
                "Το ID πρέπει να είναι ακέραιος.", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Σφάλμα βάσης: " + ex.getMessage(), "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
    }
}
